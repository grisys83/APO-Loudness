ApoLoudness v0.3.1
==================

Installation:
1. Copy all files and folders to your desired location
2. Make sure all DLLs listed in REQUIRED_DLLS.txt are present
3. Run ApoLoudness.exe

Requirements:
- Windows 10 or later (64-bit)
- EqualizerAPO installed

Controls:
- Mouse Wheel: Adjust offset (manual) or target (auto/calibration)
- Ctrl + Wheel: Adjust target phon
- Right Click: Context menu
- Double Click: Reset (Target=Real=60dB with Auto Offset)
- Right Mouse + Wheel: Global volume adjust (Auto Offset ON)

Calibration:
Run ApoLoudnessCalibration.exe to calibrate your system
